// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyArouhyTe5ifDKfzUhkvyYeaCLW2Cg7Uec",
    authDomain: "todo-list-b71cb.firebaseapp.com",
    projectId: "todo-list-b71cb",
    storageBucket: "todo-list-b71cb.appspot.com",
    messagingSenderId: "210702153903",
    appId: "1:210702153903:web:bea7ec22be27980bd5fc5a"
  };
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);